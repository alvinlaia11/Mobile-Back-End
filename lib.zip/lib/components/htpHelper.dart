import 'package:http/http.dart' as http;
import 'dart:io';

class HttpHelper {
  final String _urlKey = "?api_key=0d72e996140b018b48a13abccd2860f9";
  final String _urlBase = "https://api.themoviedb.org/";
  Future<String> getMovie() async {
    var url = Uri.parse(_urlBase + '/3/movie/now_playing' + _urlKey);
    http.Response result = await http.get(url);
    if (result.statusCode == HttpStatus.ok) {
      String responseBody = result.body;
      return responseBody;
    }
    return result.statusCode.toString();
  }
}
